<hr>
<footer>
    <p>&copy; 2026 Event Management System</p>
</footer>
</body>
</html>
