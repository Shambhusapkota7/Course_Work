<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Event Management System</title>

    <!-- CSS -->
    <link rel="stylesheet" href="/COURSE_WORK/Event%20Management%20System/assets/css/style.css">

    <!-- JS -->
    <script src="/COURSE_WORK/Event%20Management%20System/assets/js/ajax.js" defer></script>
</head>
<body>
<h1>Event Management System</h1>
<hr>
